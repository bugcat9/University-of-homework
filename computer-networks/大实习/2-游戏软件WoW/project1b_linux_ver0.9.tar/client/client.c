/**************************************************************************
 * The reference client implementation of the EE122 Project #1
 *
 * Author: Junda Liu (liujd@cs)
 * Author: DK Moon (dkmoon@cs)
 * Author: David Zats (dzats@cs)
**************************************************************************/

#include <arpa/inet.h>  /* for inet_ntoa() */
#include <ctype.h>      /* for isalnum() */
#include <errno.h>      /* for perror() */
#include <netinet/in.h> /* for struct sockaddr_in */
#include <signal.h>     /* for signal() */
#include <stdio.h>      /* for fprintf() */
#include <stdint.h>     /* for uint16_t, uint32_t, ... */
#include <stdlib.h>     /* for exit() */
#include <string.h>     /* for memset(), strstr() */
#include <sys/select.h> /* for select() */
#include <sys/socket.h> /* for socket() */
#include <sys/types.h>  /* for socket() */
#include <time.h>       /* for nanosleep() */
#include <unistd.h>     /* for getopt(), read(), write(), ... */

#include "../messages.h"
#include "../protocol.h"

#ifndef __cplusplus
typedef int bool;
enum {false = 0, true = 1};
#endif

/* Player data structure to keep track of players in sight. */
typedef struct player {
  const char *name_;
  int32_t hp_;
  int32_t exp_;
  int8_t x_;
  int8_t y_;

  /* Pointer to implement the linked list of players. */
  struct player *next_;
} player_t;

/* Data structure to buffer command line input and socket input/output. */
struct buffer {
  uint8_t *ptr_;
  size_t capacity_;
  size_t len_;
};

/* Server IP address and port number. */
static const char *s_serverIP;
static uint16_t s_serverPort;

static struct buffer s_command;
static struct buffer s_input;
static struct buffer s_output;

/* All players in the game. */
static player_t *s_players = (player_t *) 0;

/* Current player information. */
static const char *s_playerName;
static const char *s_loginName;
static uint8_t s_currentX;
static uint8_t s_currentY;

/* Related to fault injection */
static int s_faultInvalidVersion = 0;
static int s_faultInvalidLength = 0;
static int s_faultInvalidMsgType = 0;
static int s_faultInvalidDirection = 0;
static int s_faultInvalidPlayerName = 0;
static int s_faultInvalidSpeakMsg = 0;
static int s_faultSlowLink = 0;
static int s_faultAbnormalTermination = 0;

/* For debugging */
static bool s_verbose = false;


/* Simple utility function to take the maximum. */
static inline int max(int a, int b)
{
  return (a > b) ? a : b;
}


/* Finds a player with the given name. */
static player_t *player_find(const char *name)
{
  player_t *player;
  assert(name);
  for (player = s_players; player; player = player->next_) {
    assert(player->name_);
    if (!strcmp(name, player->name_)) return player;
  }
  return (player_t *) 0;
}


/* Creates a named player. */
static player_t *player_insert(const char *name)
{
  player_t *player = malloc(sizeof(player_t));
  assert(player);
  memset(player, 0, sizeof(*player));

  assert(strlen(name) <= EE122_MAX_NAME_LENGTH);
  player->name_ = strdup(name);

  player->next_ = s_players;
  s_players = player;
  return player;
}


/* Removes the named player from the player list. */
static void player_remove(const char *name)
{
  player_t *prev, *current, *next;
  for (prev = NULL, current = s_players; current; current = next) {
    next = current->next_;
    if (!strcmp(current->name_, name)) {
      if (prev) prev->next_ = next;
      else s_players = next;
      return;
    }
  }
}


/* Returns true if the target location is visible from the view point. */
static bool can_see_location_from(const int target_x, const int target_y,
                                 const int viewpoint_x, const int viewpoint_y)
{
  if (viewpoint_x - EE122_VISION_RANGE / 2 > target_x ||
      viewpoint_x + EE122_VISION_RANGE / 2 < target_x) {
    return false;
  }
  if (viewpoint_y - EE122_VISION_RANGE / 2 > target_y ||
      viewpoint_y + EE122_VISION_RANGE / 2 < target_y) {
    return false;
  }
  return true;
}


/* Returns true if the location is in my sight. */
static bool can_see_location(const int x, const int y)
{
  return can_see_location_from(x, y, s_currentX, s_currentY);
}


/* Returns true if the player is in my sight. */
static bool can_see(const char *player_name)
{
  player_t *player;
  /* Self can always be seen. */
  if (!strcmp(player_name, s_playerName)) return true;
  /* I don't know about the player. */
  if (player = player_find(player_name), !player) return false;
  else return can_see_location(player->x_, player->y_);
}


/* Function to show how to use this program. */
static void usage(const char *bin)
{
  fprintf(stdout, "! Usage: %s -p <port_number> -s <server_ip>\n", bin);
  fprintf(stdout, "  optionally, -v for verbose output.\n");
}


/* Function to parse program arguments. */
static void parse_arguments(int argc, char **argv)
{
  int opt;
  /* If you are not familiar with getopt() function, please refer to its 
     man page. This function and its sibling getopt_long() are very useful
     to parse program arguments. Moreover, many programming languages
     including python and perl provide their counterparts. */
  while (opt = getopt(argc, argv, "p:s:vh"), opt != -1) {
    switch (opt) {
      case 'p': s_serverPort = atoi(optarg); break;
      case 's': s_serverIP = strdup(optarg); break;
      case 'v': s_verbose = true; break;
      case 'h': usage(argv[0]); exit(0);
      default: fprintf(stdout, "! Invalid argument: '%c'\n", (char) opt);
               usage(argv[0]);
               exit(1);
    }
  }
}


/* Function to enqueue the given message. */
static void enqueue_outgoing_message(const struct ee122_hdr *header)
{
  /* Appends to the output buffer. Resizes it if necessary. */
  if (s_output.capacity_ < s_output.len_ + ntohs(header->length_)) {
    s_output.capacity_ += 65536;
    s_output.ptr_ = realloc(s_output.ptr_, s_output.capacity_);
  }
  memcpy(s_output.ptr_ + s_output.len_, header, ntohs(header->length_));
  s_output.len_ += ntohs(header->length_);
  if (s_verbose) {
    int i;
    size_t length = ntohs(header->length_);
    printf("enqueued msg ver:%d len:%d type:%d "
           "raw_pkt(net_byte_order)=[",
           header->version_, length, header->type_);
    for (i = 0; i < length; ++ i) {
      printf("%02x ", ((uint8_t *) header)[i]);
    }
    printf("]\n");
  }
}


/* Returns 0 if no error. Returns non-zero on failure. */
static int process_login_command(const char *command,
                                 const char *line,
                                 const size_t line_len)
{
  uint8_t msg[65536];
  struct ee122_hdr *header = (struct ee122_hdr *) msg;
  struct ee122_login_request *login;
  const char *name;
  if (name = strtok(NULL, " \t"), !name) {
    fprintf(stdout, "! Invalid syntax\n");
    return 1;
  }
  if (!check_player_name(name)) {
    fprintf(stdout, "! Invalid name: %s\n", name);
    return 2;
  }
  /* Remembers the login name. */
  if (s_loginName) free((void *) s_loginName);
  s_loginName = strdup(name);
  /* Constructs a network message. */
  header->version_ = EE122_VALID_VERSION;
  header->type_ = LOGIN_REQUEST;
  header->length_ = htons(sizeof(struct ee122_hdr) +
                          sizeof(struct ee122_login_request));
  login = (struct ee122_login_request *) header->payload_;
  strcpy(login->player_name_, s_loginName);
  /* Injects faults */
  if (s_faultInvalidVersion)
    header->version_ += 1;
  if (s_faultInvalidLength)
    header->length_ = htons(ntohs(header->length_) - 1);
  if (s_faultInvalidMsgType)
    header->type_ = MAX_MESSAGE;
  if (s_faultInvalidPlayerName)
    login->player_name_[0] = 0x01;
  /* Appends to the output buffer. */
  enqueue_outgoing_message(header);
  return 0;
}


/* Returns 0 if no error. Returns non-zero on failure. */
static int process_move_command(const char *command,
                                const char *line,
                                const size_t line_len)
{
  uint8_t msg[65536];
  struct ee122_hdr *header = (struct ee122_hdr *) msg;
  const char *direction;
  struct ee122_move *move;
  if (direction = strtok(NULL, " \t"), !direction) {
    fprintf(stdout, "! Invalid syntax\n");
    return 1;
  }
  /* Constructs a network message. */
  header->version_ = EE122_VALID_VERSION;
  header->type_ = MOVE;
  header->length_ = htons(sizeof(struct ee122_hdr) + 
                          sizeof(struct ee122_move));
  move = (struct ee122_move *) header->payload_;
  if (!strcasecmp(direction, "north")) {
    move->direction_ = NORTH;
  } else if (!strcasecmp(direction, "south")) {
    move->direction_ = SOUTH;
  } else if (!strcasecmp(direction, "east")) {
    move->direction_ = EAST;
  } else if (!strcasecmp(direction, "west")) {
    move->direction_ = WEST;
  } else {
    fprintf(stdout, "! Invalid direction: %s\n", direction);
    return 2;
  }
  /* Injects faults */
  if (s_faultInvalidVersion)
    header->version_ += 1;
  if (s_faultInvalidLength)
    header->length_ = htons(ntohs(header->length_) - 1);
  if (s_faultInvalidMsgType)
    header->type_ = MAX_MESSAGE;
  if (s_faultInvalidDirection)
    move->direction_ = 10;
  /* Appends to the output buffer. */
  enqueue_outgoing_message(header);
  return 0;
}


/* Returns 0 if no error. Returns non-zero on failure. */
static int process_attack_command(const char *command,
                                  const char *line,
                                  const size_t line_len)
{
  uint8_t msg[65536];
  struct ee122_hdr *header = (struct ee122_hdr *) msg;
  const char *victim_name;
  struct ee122_attack *attack;
  if (victim_name = strtok(NULL, " \t"), !victim_name) {
    fprintf(stdout, "! Invalid syntax\n");
    return 1;
  }
  if (!check_player_name(victim_name)) {
    fprintf(stdout, "! Invalid name: %s\n", victim_name);
    return 2;
  }
  /* Ignores attacking self. */
  if (s_playerName && !strcmp(victim_name, s_playerName)) {
    return 3;
  }
  /* Checks visibility. */
  if (s_playerName && !can_see(victim_name)) {
    on_not_visible();
    return 4;
  }
  /* Constructs a network message. */
  header->version_ = EE122_VALID_VERSION;
  header->type_ = ATTACK;
  header->length_ = htons(sizeof(struct ee122_hdr) + 
                          sizeof(struct ee122_attack));
  attack = (struct ee122_attack *) header->payload_;
  strcpy(attack->victim_name_, victim_name);
  /* Injects faults */
  if (s_faultInvalidVersion)
    header->version_ += 1;
  if (s_faultInvalidLength)
    header->length_ = htons(ntohs(header->length_) - 1);
  if (s_faultInvalidMsgType)
    header->type_ = MAX_MESSAGE;
  if (s_faultInvalidPlayerName)
    attack->victim_name_[0] = 0x02;
  /* Appends to the output buffer. */
  enqueue_outgoing_message(header);
  return 0;
}


/* Returns 0 if no error. Returns non-zero on failure. */
static int process_speak_command(const char *command,
                                 const char *line,
                                 const size_t line_len)
{
  uint8_t msg[65536];
  struct ee122_hdr *header = (struct ee122_hdr *) msg;
  struct ee122_speak *speak;
  size_t text_off;
  size_t reply_len;
  /* Removes the leading spaces. */
  for (text_off = strlen(command) + 1;
       text_off < line_len && line[text_off] && line[text_off] == ' ';
       ++ text_off);
  if (text_off >= line_len || !check_player_message(line + text_off)) {
    fprintf(stdout, "! Invalid text message.\n");
    return 1;
  }
  /* Constructs a network message. We pad to make it 32bit aligned. */
  reply_len = sizeof(struct ee122_hdr) + sizeof(struct ee122_speak) +
              strlen(line + text_off) + 1;
  reply_len = (reply_len + 3) / 4 * 4;
  header->version_ = EE122_VALID_VERSION;
  header->type_ = SPEAK;
  header->length_ = htons(reply_len);
  speak = (struct ee122_speak *) header->payload_;
  memset(speak, 0, reply_len - (header->payload_ - (uint8_t *) header));
  strcpy(speak->msg_, line + text_off);
  /* Injects faults */
  if (s_faultInvalidVersion)
    header->version_ += 1;
  if (s_faultInvalidLength)
    header->length_ = htons(ntohs(header->length_) - 1);
  if (s_faultInvalidMsgType)
    header->type_ = MAX_MESSAGE;
  if (s_faultInvalidSpeakMsg)
    speak->msg_[0] = 0x01;
  /* Appends to the output buffer. */
  enqueue_outgoing_message(header);
  return 0;
}


/* Returns 0 if no error. Returns non-zero on failure. */
static int process_logout_command(const char *command,
                                  const char *line,
                                  const size_t line_len)
{
  uint8_t msg[65536];
  struct ee122_hdr *header = (struct ee122_hdr *) msg;
  /* Constructs a network message. */
  header->version_ = EE122_VALID_VERSION;
  header->type_ = LOGOUT;
  header->length_ = htons(sizeof(struct ee122_hdr));
  /* Injects faults */
  if (s_faultInvalidVersion)
    header->version_ += 1;
  if (s_faultInvalidLength)
    header->length_ = htons(ntohs(header->length_) - 1);
  if (s_faultInvalidMsgType)
    header->type_ = MAX_MESSAGE;
  /* Appends to the output buffer. */
  enqueue_outgoing_message(header);
  return 0;
}


/* Returns 0 if no error. Returns non-zero on failure.
   This function enables/disables a particular fault. */
static int process_fault(const char *command,
                         const char *line,
                         const size_t line_len)
{
  struct fault_t {
    const char *name_;
    int32_t *value_ptr_;
  };
  static struct fault_t fault_map[] = {
    {"version", &s_faultInvalidVersion},
    {"length", &s_faultInvalidLength},
    {"message_type", &s_faultInvalidMsgType},
    {"direction", &s_faultInvalidDirection},
    {"player_name", &s_faultInvalidPlayerName},
    {"speak_message", &s_faultInvalidSpeakMsg},
    {"slow_link", &s_faultSlowLink},
    {"abnormal_termination", &s_faultAbnormalTermination},
  };
  static size_t num_faults = sizeof(fault_map) / sizeof(fault_map[0]);

  int enable = 0;
  const char *fault;
  size_t i, length;
  int found = -1;
  bool ambiguous = false;

  if (!strncasecmp(command, "show_faults", strlen(command))) {
    for (i = 0; i < num_faults; ++ i) {
      fprintf(stdout, "* Fault ``%s'' is %s.\n",
              fault_map[i].name_,
              *(fault_map[i].value_ptr_) ? "on" : "off");
    }
    return 0;
  }

  if (!strncasecmp(command, "enable_fault", strlen(command)))
    enable = 1;
  if (fault = strtok(NULL, " \t"), !fault) {
    fprintf(stdout, "! Invalid syntax. Fault name is not given.\n");
    fprintf(stdout, "! usage: enable|disable <fault_name>\n");
    fprintf(stdout, "! fault_name := ");
    for (i = 0; i < num_faults; ++ i) {
      fprintf(stdout, "%s", fault_map[i].name_);
      if (i + 1 != num_faults) fprintf(stdout, ", ");
    }
    fprintf(stdout, "\n");
    fprintf(stdout, "Partial fault name also works.\n"); 
    return 1;
  }
  length = strlen(fault);
  for (i = 0; i < num_faults; ++ i) {
    if (!strncasecmp(fault_map[i].name_, fault, length)) {
      if (found == -1) found = i;
      else ambiguous = true;
    }
  }
  if (found == -1) {
    fprintf(stdout, "! No such fault ``%s''.\n", fault);
    return 2;
  }
  if (ambiguous) {
    fprintf(stdout, "! Ambiguous fault ``%s''.\n", fault);
    return 3;
  }
  *(fault_map[found].value_ptr_) = enable;
  fprintf(stdout, "* Fault ``%s'' is %s.\n",
          fault_map[found].name_, enable ? "on" : "off");
  return 0;
}


/* Returns 0 if no error, Returns non-zero, otherwise. */
static int process_command_line()
{
  typedef int (*command_handler_t)(const char *command,
                                   const char *line,
                                   size_t line_len);
  typedef struct {
    const char *command_;
    command_handler_t handler_;
  } command_t; 

  static command_t command_map[] = {
    {"login", process_login_command},
    {"move", process_move_command},
    {"attack", process_attack_command},
    {"speak", process_speak_command},
    {"logout", process_logout_command},
    {"enable_fault", process_fault},
    {"disable_fault", process_fault},
    {"show_faults", process_fault},
  };

  static size_t num_commands = sizeof(command_map) / sizeof(command_map[0]);

  size_t offset = 0;

  while (1) {
    size_t line_start, new_line;
    const char *command;
    char *line;
    size_t line_len;
    size_t i;
    int found = -1;
    bool ambiguous = false;

    /* Checks if we have a line. */
    for (line_start = new_line = offset;
         new_line < s_command.len_;
         ++ new_line) {
      if (s_command.ptr_[new_line] == '\n') break;
    }
    /* Not enough bytes? Then, we will wait more. */
    if (new_line == s_command.len_) break;
    /* Takes the line. Moves the offset. */
    s_command.ptr_[new_line] = '\0';
    line = (char *) s_command.ptr_ + offset;
    line_len = new_line - offset;
    offset = new_line + 1;

    /* The first word is the command, and the remaining string is argument.
       Skips an empty line. */
    if (command = strtok(line, " \t"), !command) continue;

    /* Per-command handling. */
    for (i = 0; i < num_commands; ++ i) {
      if (!strncasecmp(command_map[i].command_, command, strlen(command))) {
        if (found == -1) found = i;
        else ambiguous = true;
      }
    }
    if (found == -1) {
      fprintf(stdout, "! Invalid command: %s.\n", command);
      fprintf(stdout, "Available commands = ");
      for (i = 0; i < num_commands; ++ i) {
        fprintf(stdout, "%s", command_map[i].command_);
        if (i + 1 != num_commands) fprintf(stdout, ", ");
      }
      fprintf(stdout, "\n");
      fprintf(stdout, "Partial command name also works.\n"); 
    } else if (ambiguous) {
      fprintf(stdout, "! Ambiguous command: %s.\n", command);
    } else {
      command_map[found].handler_(command, line, line_len);
    }
  }

  /* If processed any command, we compact the buffer. This is not much
     efficient code. We can do better with a circular buffer. */
  if (offset > 0) {
    memmove(s_command.ptr_, s_command.ptr_ + offset, s_command.len_ - offset);
    s_command.len_ -= offset;
    show_prompt();
  }

  return 0;
}


/* Handler for LOGIN_REPLY. Returns 0 if no error. */
static int process_login_reply(struct ee122_hdr *header)
{
  struct ee122_login_reply *reply = (void *) (header->payload_);
  /* Checks the location. */
  if (reply->x_ >= EE122_SIZE_X || reply->y_ >= EE122_SIZE_Y) {
    on_malformed_message_from_server();
    return 1;
  }
  /* Checks the HP and EXP. */
  if ((int) ntohl(reply->hp_) < 0 || (int) ntohl(reply->exp_) < 0) {
    on_malformed_message_from_server();
    return 2;
  }
  /* Converts network byte endian to host byte endian. */
  reply->hp_ = ntohl(reply->hp_);
  reply->exp_ = ntohl(reply->exp_);
  /* Checks the error code. */
  if (reply->error_code_ > 1) {
    on_malformed_message_from_server();
    return 3;
  }
  on_login_reply(reply->error_code_);
  /* Initializes the name. */
  if (s_playerName) free((void *) s_playerName);
  s_playerName = strdup(s_loginName);
  /* Initializes the location. */
  s_currentX = reply->x_;
  s_currentY = reply->y_;
  return 0;
}


/* Handler for MOVE_NOTIFY. Returns 0 if no error. */
static int process_move_notify(struct ee122_hdr *header)
{
  struct ee122_move_notify *notify = (void *) (header->payload_);
  player_t *player;
  /* I'm not logged in, yet. Ignore the packet. */
  if (!s_playerName) {
    fprintf(stdout, "! Warning: it seems that you send move_notify to a FD"
                    "not yet logged in. You better avoid this.\n");
    return 0;
  }
  /* Checks the X, Y location. */
  if (notify->x_ >= EE122_SIZE_X || notify->y_ >= EE122_SIZE_Y) {
    on_malformed_message_from_server();
    return 1;
  }
  /* Checks the name. */
  if (!check_player_name(notify->player_name_)) {
    on_malformed_message_from_server();
    return 2;
  }
  /* Checks the HP and EXP. */
  if ((int) ntohl(notify->hp_) < 0 || (int) ntohl(notify->exp_) < 0) {
    on_malformed_message_from_server();
    return 3;
  }
  /* Updates the information. */
  if (player = player_find(notify->player_name_), !player) {
    player = player_insert(notify->player_name_);
  }
  player->hp_ = ntohl(notify->hp_);
  player->exp_ = ntohl(notify->exp_);
  player->x_ = notify->x_;
  player->y_ = notify->y_;
  /* If the player is me, I will update my location and show me players
     who were invisible before. */
  if (!strcmp(player->name_, s_playerName)) {
    player_t *other;
    int old_x = s_currentX;
    int old_y = s_currentY;
    s_currentX = notify->x_;
    s_currentY = notify->y_;
    for (other = s_players; other; other = other->next_) {
      /* Do not send to me. */
      if (other == player) continue;
      /* The player was invisible and now visible? */
      if (!can_see_location_from(other->x_, other->y_, old_x, old_y) &&
          can_see_location_from(other->x_, other->y_, s_currentX, s_currentY)) {
        on_move_notify(other->name_, other->x_, other->y_,
                       other->hp_, other->exp_);
      }
    }
  }
  /* Checks visibility. */
  if (can_see_location(notify->x_, notify->y_)) {
    on_move_notify(notify->player_name_, notify->x_, notify->y_,
                   ntohl(notify->hp_), ntohl(notify->exp_));
  }

  return 0;
}


/* Handler for ATTACK_NOTIFY. Returns 0 if no error. */
static int process_attack_notify(struct ee122_hdr *header)
{
  struct ee122_attack_notify *notify = (void *) (header->payload_);
  /* I'm not logged in, yet. Ignore the packet. */
  if (!s_playerName) {
    fprintf(stdout, "! Warning: it seems that you send attack_notify to a FD"
                    "not yet logged in. You better avoid this.\n");
    return 0;
  }
  /* Checks the names. */
  if (!check_player_name(notify->attacker_name_) ||
      !check_player_name(notify->victim_name_)) {
    on_malformed_message_from_server();
    return 1;
  }
  /* Checks the HP and EXP. */
  if ((int) ntohl(notify->hp_) < 0 || (int) ntohl(notify->damage_) < 0) {
    on_malformed_message_from_server();
    return 2;
  }
  /* Checks visibility. */
  if (can_see(notify->attacker_name_) && can_see(notify->victim_name_)) {
    on_attack_notify(notify->attacker_name_, notify->victim_name_,
                     notify->damage_, ntohl(notify->hp_));
  }
  return 0;
}


/* Handler for SPEAK_NOTFY. Returns 0 if no error. */
static int process_speak_notify(struct ee122_hdr *header)
{
  struct ee122_speak_notify *notify = (void *) (header->payload_);
  size_t i, msg_len;
  if (!s_playerName) {
    fprintf(stdout, "! Warning: it seems that you send speak_notify to a FD"
                    "not yet logged in. You better avoid this.\n");
    return 0;
  }
  if (!check_player_name(notify->broadcaster_name_)) {
    on_malformed_message_from_server();
    return 1;
  }
  msg_len = ((char *) header + header->length_) - notify->msg_;
  /* The message must be printable and null-terminated. */
  for (i = 0; i < msg_len; ++ i) {
    if (notify->msg_[i] == '\0') break;
    if (!isprint(notify->msg_[i])) {
      on_malformed_message_from_server();
      return 2;
    }
  }
  /* Null terminated? */
  if (i == msg_len) {
    on_malformed_message_from_server();
    return 3;
  }
  /* Msg too long? */
  if (i > EE122_MAX_MSG_LENGTH) {
    on_malformed_message_from_server();
    return 4;
  }
  on_speak_notify(notify->broadcaster_name_, notify->msg_);
  return 0;
}


/* Handler for LOGOUT_NOTITY. Returns 0 if no error. */
static int process_logout_notify(struct ee122_hdr *header)
{
  struct ee122_logout_notify *notify = (void *) (header->payload_);
  if (!s_playerName) {
    fprintf(stdout, "! Warning: it seems that you send logout_notify to a FD"
                    "not yet logged in. You better avoid this.\n");
    return 0;
  }
  if (!check_player_name(notify->player_name_)) {
    on_malformed_message_from_server();
    return 1;
  }
  on_exit_notify(notify->player_name_);
  player_remove(notify->player_name_);
  return 0;
}


/* Handler for INVALID_STATE. Returns 0 if no error. */
static int process_invalid_state(struct ee122_hdr *header)
{
  struct ee122_invalid_state *msg = (void *) (header->payload_);
  /* Checks the error code */
  if (msg->error_code_ > 1) {
    on_malformed_message_from_server();
    return 1;
  }
  on_invalid_state(msg->error_code_);
  return 0;
}


/* Returns 0 if no error. Returns non-zero, otherwise. */
static int process_socket()
{
  /* Type definition of a message handler. */
  typedef int (*message_handler_t)(struct ee122_hdr *);

  /* We will initialize the message map only once. */
  static bool initialized = false;
  static message_handler_t message_handlers[MAX_MESSAGE] = {NULL, };

  size_t offset = 0;

  /* Initializes the message map. */
  if (initialized == false) {
    initialized = true;
    message_handlers[LOGIN_REPLY] = process_login_reply;
    message_handlers[MOVE_NOTIFY] = process_move_notify;
    message_handlers[ATTACK_NOTIFY] = process_attack_notify;
    message_handlers[SPEAK_NOTIFY] = process_speak_notify;
    message_handlers[LOGOUT_NOTIFY] = process_logout_notify;
    message_handlers[INVALID_STATE] = process_invalid_state;
  }

  /* Tries to process server messages. */
  while (1) {
    struct ee122_hdr *header;
    size_t length;

    /* Checks if we have enough bytes for a header. */
    if (s_input.len_ - offset < sizeof(struct ee122_hdr)) {
      break;
    }
    header = (struct ee122_hdr *) (s_input.ptr_ + offset);

    /* Converts network byte endian to host byte endian. */
    length = ntohs(header->length_);

    /* Checks the header's sanity. The version must be 4 and the message
       length must be greater than or equal to the header length. And the
       message length must be 4-byte aligned. */
    if (header->version_ != EE122_VALID_VERSION) {
      on_malformed_message_from_server();
      return 1;
    }
    if (length < sizeof(struct ee122_hdr) || length % 4 != 0) {
      on_malformed_message_from_server();
      return 2;
    }

    /* Checks if we have enough bytes for this message. */
    if (s_input.len_ - offset < length) {
      break;
    }

    /* We have enough bytes to construct a message. Processes it. */
    header->length_ = ntohs(header->length_);
    offset += header->length_;

    /* Per-message handling. */
    if (header->type_ < MAX_MESSAGE && message_handlers[header->type_]) {
      if (s_verbose) {
        int i;
        header->length_ = htons(header->length_);
        printf("received msg ver:%d len:%d type:%d "
               "raw_pkt(net_byte_order)=[",
               header->version_, ntohs(header->length_), header->type_);
        for (i = 0; i < ntohs(header->length_); ++ i) {
          printf("%02x ", ((uint8_t *) header)[i]);
        }
        printf("]\n");
        header->length_ = ntohs(header->length_);
      }
      int err = message_handlers[header->type_](header);
      if (err) return err;
    } else {
      on_malformed_message_from_server();
      return 3;
    }
  }

  /* If processed any packet, we compact the buffer. This is not much
     efficient code. We can do better with a circular buffer. */
  if (offset > 0) {
    memmove(s_input.ptr_, s_input.ptr_ + offset, s_input.len_ - offset);
    s_input.len_ -= offset;
  }
  return 0;
}


/* Function to handle the socket and the user input. */
int main_loop(fd)
{
  while (true) {
    int max_fd = -1;
    fd_set readable, writable;

    /* Initializes the fd_sets. Since select() updates the set, we must
       reset the set every time. */
    FD_ZERO(&readable);
    FD_ZERO(&writable);

    /* We will read from and write to the socket descriptor. */
    FD_SET(fd, &readable);
    if (s_output.len_ > 0) FD_SET(fd, &writable);
    max_fd = max(max_fd, fd);

    /* We will read commands from the standard input stream. */
    FD_SET(STDIN_FILENO, &readable);
    max_fd = max(max_fd, STDIN_FILENO);

    /* Waits until some descriptors are ready.
       Note the exceptfd of the select (i.e. the 4th argument) indicates 
       out-of-band status. It is not related to a closed socket. If socket
       is closed by the other side, it will be treated as "readable" and we
       will read 0 byte. */
    if (select(max_fd + 1, &readable, &writable, NULL, NULL) < 0) {
      perror("! select");
      /* Retries it if failed. */
      continue;
    }

    /* Is the standard input is ready? Then, we read bytes and check if 
       there's enough bytes for a command. If so, we will convert the
       command into a network message. Otherwise, we will enqueue the
       partial command and wait for more bytes to complete the command. */
    if (FD_ISSET(STDIN_FILENO, &readable)) {
      int read_bytes;
      /* If we do not have enough buffer, we resize it first. */
      if (s_command.len_ == s_command.capacity_) {
        s_command.capacity_ += 65536;
        s_command.ptr_ = realloc(s_command.ptr_, s_command.capacity_);
        assert(s_command.ptr_);
      }
      /* Reads from the standard input as many bytes as the remaining
         buffer. But the actual number of bytes read might be less than
         the requested size. */
      read_bytes = read(STDIN_FILENO, s_command.ptr_ + s_command.len_,
                        s_command.capacity_ - s_command.len_);
      if (read_bytes < 0) {  /* Error */
        perror("! read");
        return 1;
      } else if (read_bytes == 0) {  /* EOF */
        fprintf(stdout, "! The standard input has closed.\n");
        return 0;
      } else {
        s_command.len_ += read_bytes;
        /* Tries to process the input. If we can complete one command, 
           we will convert it into a network message to the server. */
        if (process_command_line() != 0) return 1;
      }
    }

    /* Is the socket ready? If so, we read bytes and queue them. */
    if (FD_ISSET(fd, &readable)) {
      int read_bytes;
      /* If we do not have enough buffer, resize it first. */
      if (s_input.len_ == s_input.capacity_) {
        s_input.capacity_ += 65536;
        s_input.ptr_ = realloc(s_input.ptr_, s_input.capacity_);
        assert(s_input.ptr_);
      }
      /* Reads from the socket. Then, tries to decode a network message.
         It's also OK to call read() instead of recv(). */
      read_bytes = recv(fd,
                        s_input.ptr_ + s_input.len_,
                        s_input.capacity_ - s_input.len_, 0);
      if (read_bytes < 0) {  /* Error */
        perror("! recv");
        return 1;
      } else if (read_bytes == 0) {  /* The connection is closed. */
        on_disconnection_from_server();
        return 0;
      } else {
        s_input.len_ += read_bytes;
        /* Processes server messages. */
        if (process_socket() != 0) return 1;
      }
    }

    /* Flushes the output buffer if possible. */
    if (FD_ISSET(fd, &writable) && s_output.len_ > 0) {
      int to_send, sent_bytes;

      /* If we are emulating a slow link, send byte-by-byte. */
      to_send = s_output.len_;
      if (s_faultSlowLink) to_send = 1;
      else if (s_faultAbnormalTermination) to_send -= 1;

      sent_bytes = send(fd, s_output.ptr_, to_send, 0);
      if (sent_bytes < 0) {
        perror("! send");
        return 1;
      } else {
        /* Adjusts the buffer. This is not much efficient due to
           memmove(), but it's simple. :-) If you're worried about 
           efficiency, you can implement a circular queue using two 
           pointers. */
        memmove(s_output.ptr_,
                s_output.ptr_ + sent_bytes,
                s_output.len_ - sent_bytes);
        s_output.len_ -= sent_bytes;
      }
      /* If we are emulating a slow link, add delay. */
      if (s_faultSlowLink) {
        struct timespec req = {0, 1 * 1000 * 1000};
        nanosleep(&req, NULL);
      }
      /* If we are emulating abnormal termination, just stop here. */
      if (s_faultAbnormalTermination) {
        fprintf(stdout, "* Emulating an abnormal termination.\n");
        sleep(1);
        exit(1);
      }
    }
  }
}


int main(int argc, char **argv)
{
  int fd;
  struct sockaddr_in sin;
  player_t *current, *next;

  /* Changes the buffering mode to non-buffering to get error message
     immediately. */
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  /* Ignores the PIPE error. This can happen when we try to send out to
     the closed server. */
  signal(SIGPIPE, SIG_IGN);

  /* Parses the passed arguments. Checks the required arguments. */
  parse_arguments(argc, argv);
  if (!s_serverPort) {
    fprintf(stdout, "! The server port number is not defined.\n");
    usage(argv[0]);
    return 1;
  }
  if (!s_serverIP) {
    fprintf(stdout, "! The server ip address is not defined\n");
    usage(argv[0]);
    return 1;
  }
  /* If you're not familiar with inet_ntoa() and inet_addr(), please
     refer to the man pages. They translate between a human readable
     IP address and its binary representation. If you want to retrieve
     an IP address from a host name, you may want to use
     gethostbyname() instead of inet_ntoa(). */
  if (inet_addr(s_serverIP) == INADDR_NONE) {
    fprintf(stdout, "! The server address must be an IP address.\n");
    usage(argv[0]);
    return 1;
  }

  /* Opens a socket.*/
  if (fd = socket(PF_INET, SOCK_STREAM, 0), fd < 0) {
    perror("! socket");
    return 1;
  }

  /* Connect to the server. Do not forget to call htons when specifying the
     port number. And do not confuse between htonl and htons. The former
     is for 32bit numbers and the latter is for 16bit numbers. (The
     suffixes 'l' and 's' mean 'long' and 'short', respectively.) */
  memset(&sin, 0, sizeof(sin));
  sin.sin_family = PF_INET;
  sin.sin_addr.s_addr = inet_addr(s_serverIP);
  sin.sin_port = htons(s_serverPort);
  if (connect(fd, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
    on_client_connect_failure();
    close(fd);
    return 1;
  }

  show_prompt();

  /* Enters the main loop. It terminates when the user types in "exit". */
  main_loop(fd);

  /* Cleans the memory. */
  for (current = s_players; current; current = next) {
    next = current->next_;
    free((void *) current->name_);
    free((void *) current);
  }
  if (s_playerName) free((void *) s_playerName);
  if (s_loginName) free((void *) s_loginName);
  if (s_serverIP) free((void *) s_serverIP);

  /* Linux programs usually exits with 0 on successful completion and
     returns non-zero error code on failure. */
  return 0;
}
